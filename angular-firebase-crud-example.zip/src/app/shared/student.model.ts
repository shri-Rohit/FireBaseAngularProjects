export class Student {
    id: string;
    fullName: string;
    rollNo: string;
    branchName: string;
    guardianPhoneNo: string;
}
